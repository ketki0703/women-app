import 'package:flutter/material.dart';
import 'package:flutterapp/womenapp/generatedimagewidget/GeneratedImageWidget.dart';
import 'package:flutterapp/womenapp/generatedcycles1widget/GeneratedCycles1Widget.dart';
import 'package:flutterapp/womenapp/generatedtrackers1widget/GeneratedTrackers1Widget.dart';

void main() {
  runApp(womenApp());
}

class womenApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      initialRoute: '/GeneratedImageWidget',
      routes: {
        '/GeneratedImageWidget': (context) => GeneratedImageWidget(),
        '/GeneratedCycles1Widget': (context) => GeneratedCycles1Widget(),
        '/GeneratedTrackers1Widget': (context) => GeneratedTrackers1Widget(),
      },
    );
  }
}
